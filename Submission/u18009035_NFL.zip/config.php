<?php
$db_host = "wheatley.cs.up.ac.za";
$db_user = "u18009035";
$db_pass = "G10v@nn1";
$db_name = "u18009035_NFL";
?>
